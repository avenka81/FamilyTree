#!/bin/bash
# Heritage Tree Test Runner
# Runs structural tests (fast) then browser tests (Playwright)

echo "╔══════════════════════════════════════════════╗"
echo "║       Heritage Tree Test Suite v1.0          ║"
echo "╚══════════════════════════════════════════════╝"
echo ""

PASS=0
FAIL=0

# ---- Structural Tests ----
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "🔬 LAYER 1: Structural Tests (no browser)"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
node tests/structural-tests.js
if [ $? -eq 0 ]; then
    echo "✅ Structural tests PASSED"
    PASS=$((PASS + 1))
else
    echo "❌ Structural tests FAILED"
    FAIL=$((FAIL + 1))
fi

echo ""

# ---- Browser Tests ----
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "🌐 LAYER 2: Browser Tests (Playwright)"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
node tests/browser-tests.js
if [ $? -eq 0 ]; then
    echo "✅ Browser tests PASSED"
    PASS=$((PASS + 1))
else
    echo "❌ Browser tests FAILED"
    FAIL=$((FAIL + 1))
fi

echo ""
echo "╔══════════════════════════════════════════════╗"
echo "║  OVERALL: $PASS suite(s) passed, $FAIL suite(s) failed    ║"
echo "╚══════════════════════════════════════════════╝"

exit $FAIL
